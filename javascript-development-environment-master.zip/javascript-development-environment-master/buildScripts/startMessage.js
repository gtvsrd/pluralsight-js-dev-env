import chalk from 'chalk';

/*eslint-disable no-console */

console.log(chalk.green('Starting app in dev mode...'));
